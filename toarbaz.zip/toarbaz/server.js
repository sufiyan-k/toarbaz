var express = require('express');
var app = express();
var routes=require("./routes/routers");
var bodyparser=require("body-parser");
var path=require("path");


app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended:false}))
//app.use(express.static(path.join(__dirname,"public")))

//app.use("/",routes);

app.get("/",(req,res)=>{
    res.send("Hi how r u")
});

app.listen(5000);
console.log("server started at port 5000")
